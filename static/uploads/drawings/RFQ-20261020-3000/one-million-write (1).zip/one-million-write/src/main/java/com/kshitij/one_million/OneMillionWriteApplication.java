package com.kshitij.one_million;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneMillionWriteApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneMillionWriteApplication.class, args);
	}

}
