package com.kshitij.one_million;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneMillionWriteApplicationTests {

	@Test
	void contextLoads() {
	}

}
