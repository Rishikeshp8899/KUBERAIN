package com.kshitij.one_million_write;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneMillionDeleteApplicationTests {

	@Test
	void contextLoads() {
	}

}
