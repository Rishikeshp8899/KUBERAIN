package com.kshitij.one_million_write;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneMillionDeleteApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneMillionDeleteApplication.class, args);
	}

}
